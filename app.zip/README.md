# RFQ — Send to Vendor Widget (v2 — Fully Dynamic)

## What it does

When opened on any RFQ record in Zoho CRM, the widget:

1. **Reads the current RFQ** via `ZOHO.CRM.API.getRecord` — name, owner, created date
2. **Fetches the linked products** live from `Requested_Items` / `RFQ_List` related to this specific RFQ
3. **Fetches all vendors** live from the `Vendors` module
4. User clicks **Send to Vendor** → vendor selection popup opens
5. User selects one or multiple vendors → **Create RFQ Records**
6. Widget calls the Zoho CRM API to:
   - Create a `Requested_For_Quotations` record per vendor (linked to this RFQ)
   - Create `Requested_Items` rows copied from the live RFQ products into each new record

> **Nothing is hardcoded.** All names, IDs, products, prices, and vendors come from the live CRM at runtime.

---

## Files

```
rfq-widget/
├── app/
│   └── index.html        ← The widget (HTML + CSS + JS, single file)
├── plugin-manifest.json  ← Zoho widget manifest
└── README.md
```

---

## Deploy to GitHub Pages

1. Create a GitHub repo (e.g. `rfq-widget`)
2. Push these files keeping the folder structure
3. Go to **Settings → Pages → Source: main branch / root**
4. Widget URL:
   ```
   https://<username>.github.io/rfq-widget/app/
   ```

---

## Register in Zoho CRM

1. **Setup → Developer Space → Widgets → Create Widget**

| Field | Value |
|---|---|
| Name | RFQ Send to Vendor |
| Type | Module Widget |
| Hosting | External URL |
| URL | `https://<username>.github.io/rfq-widget/app/` |
| Module | RFQs (`CustomModule23`) |

2. Save

---

## Add to RFQ Layout

1. **Setup → Modules → RFQs → Layouts → Standard**
2. Drag the widget onto the layout
3. Save

---

## API calls made at runtime

| When | Call | Purpose |
|---|---|---|
| On load | `getRecord(CustomModule23, rfqId)` | Get RFQ name, owner, created date |
| On load | `coqlQuery(Requested_Items)` | Get products linked to this RFQ |
| On load | `getRelatedRecords(RFQ_List)` | Fallback if COQL returns nothing |
| On load | `getAllRecords(Vendors)` | List all vendors for the popup |
| On save | `insertRecord(Requested_For_Quotations)` | Create one record per vendor |
| On save | `insertRecord(Requested_Items)` | Copy all line items into each record |

---

## Module & Field API names

| Label | API Name |
|---|---|
| RFQs | `CustomModule23` |
| RFQ List (linking) | `RFQ_List` |
| Requested For Quotations | `Requested_For_Quotations` (`CustomModule24`) |
| Requested Items (subform) | `Requested_Items` (`LinkingModule6`) |
| Vendors | `Vendors` |

### Requested Items subform fields

| Label | API Name | Copied from RFQ? |
|---|---|---|
| Item | `Item` (lookup → Products) | ✅ Yes |
| Expected Price | `Expected_Price` | ✅ Yes |
| Received Price | `Received_Price` | ❌ Blank (vendor fills later) |
| Description | `Description` | ✅ Yes (if present) |
| Parent | `Requested_For_Quotations` | ✅ Set to new record |
